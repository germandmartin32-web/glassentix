import type { Context, Config } from "@netlify/functions";
import { getStore } from "@netlify/blobs";

export default async (req: Request, context: Context) => {
  const password = req.headers.get("x-admin-password");
  if (!password || password !== Netlify.env.get("ADMIN_PASSWORD")) {
    return new Response(JSON.stringify({ ok: false, error: "No autorizado" }), {
      status: 401,
      headers: { "Content-Type": "application/json" },
    });
  }

  const store = getStore("reviews");
  const { blobs } = await store.list({ prefix: "review:" });

  const reviews: any[] = [];
  for (const b of blobs) {
    const data = await store.get(b.key, { type: "json" });
    if (data) reviews.push(data);
  }

  reviews.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  return new Response(JSON.stringify(reviews), {
    status: 200,
    headers: { "Content-Type": "application/json" },
  });
};

export const config: Config = {
  path: "/api/admin/reviews",
};
