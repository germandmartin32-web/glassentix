import type { Context, Config } from "@netlify/functions";
import { getStore } from "@netlify/blobs";

export default async (req: Request, context: Context) => {
  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405 });
  }

  const password = req.headers.get("x-admin-password");
  if (!password || password !== Netlify.env.get("ADMIN_PASSWORD")) {
    return new Response(JSON.stringify({ ok: false, error: "No autorizado" }), {
      status: 401,
      headers: { "Content-Type": "application/json" },
    });
  }

  try {
    const body = await req.json();
    const { id, action } = body;
    const store = getStore("reviews");
    const key = `review:${id}`;
    const data = await store.get(key, { type: "json" });

    if (!data) {
      return new Response(JSON.stringify({ ok: false, error: "No encontrada" }), {
        status: 404,
        headers: { "Content-Type": "application/json" },
      });
    }

    if (action === "delete") {
      await store.delete(key);
    } else if (action === "approve") {
      data.status = "approved";
      await store.setJSON(key, data);
    } else if (action === "reject") {
      data.status = "rejected";
      await store.setJSON(key, data);
    } else {
      return new Response(JSON.stringify({ ok: false, error: "Acción inválida" }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ ok: true }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ ok: false, error: "Error interno" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
};

export const config: Config = {
  path: "/api/admin/update",
};
