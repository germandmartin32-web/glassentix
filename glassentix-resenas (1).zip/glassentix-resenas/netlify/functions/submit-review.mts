import type { Context, Config } from "@netlify/functions";
import { getStore } from "@netlify/blobs";

const ALLOWED_TYPES = ["image/jpeg", "image/png", "image/webp", "image/gif"];
const MAX_PHOTO_BYTES = 5 * 1024 * 1024; // 5MB

export default async (req: Request, context: Context) => {
  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405 });
  }

  try {
    const form = await req.formData();
    const name = (form.get("name") || "").toString().trim().slice(0, 80);
    const rating = Math.min(5, Math.max(1, parseInt((form.get("rating") || "5").toString(), 10) || 5));
    const text = (form.get("text") || "").toString().trim().slice(0, 600);
    const photo = form.get("photo");

    if (!name || !text) {
      return new Response(JSON.stringify({ ok: false, error: "Faltan datos" }), {
        status: 400,
        headers: { "Content-Type": "application/json" },
      });
    }

    const id = crypto.randomUUID();
    let hasPhoto = false;

    if (photo && typeof photo === "object" && "size" in photo && (photo as File).size > 0) {
      const file = photo as File;

      if (file.size > MAX_PHOTO_BYTES) {
        return new Response(JSON.stringify({ ok: false, error: "La foto pesa demasiado (máx 5MB)" }), {
          status: 400,
          headers: { "Content-Type": "application/json" },
        });
      }
      if (!ALLOWED_TYPES.includes(file.type)) {
        return new Response(JSON.stringify({ ok: false, error: "Formato de imagen no soportado" }), {
          status: 400,
          headers: { "Content-Type": "application/json" },
        });
      }

      const buffer = await file.arrayBuffer();
      const photoStore = getStore("review-photos");
      await photoStore.set(`photo:${id}`, buffer, { metadata: { contentType: file.type } });
      hasPhoto = true;
    }

    const store = getStore("reviews");
    await store.setJSON(`review:${id}`, {
      id,
      name,
      rating,
      text,
      hasPhoto,
      status: "approved",
      createdAt: new Date().toISOString(),
    });

    return new Response(JSON.stringify({ ok: true }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ ok: false, error: "Error interno" }), {
      status: 500,
      headers: { "Content-Type": "application/json" },
    });
  }
};

export const config: Config = {
  path: "/api/submit-review",
};
