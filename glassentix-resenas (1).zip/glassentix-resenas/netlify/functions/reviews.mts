import type { Context, Config } from "@netlify/functions";
import { getStore } from "@netlify/blobs";

export default async (req: Request, context: Context) => {
  const store = getStore("reviews");
  const { blobs } = await store.list({ prefix: "review:" });

  const reviews: any[] = [];
  for (const b of blobs) {
    const data = await store.get(b.key, { type: "json" });
    if (data && data.status === "approved") {
      reviews.push(data);
    }
  }

  reviews.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  return new Response(JSON.stringify(reviews), {
    status: 200,
    headers: { "Content-Type": "application/json" },
  });
};

export const config: Config = {
  path: "/api/reviews",
};
