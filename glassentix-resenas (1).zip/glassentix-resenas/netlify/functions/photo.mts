import type { Context, Config } from "@netlify/functions";
import { getStore } from "@netlify/blobs";

export default async (req: Request, context: Context) => {
  const id = context.params.id;
  if (!id) {
    return new Response("Not found", { status: 404 });
  }

  const photoStore = getStore("review-photos");
  const result = await photoStore.getWithMetadata(`photo:${id}`, { type: "arrayBuffer" });

  if (!result) {
    return new Response("Not found", { status: 404 });
  }

  return new Response(result.data, {
    status: 200,
    headers: {
      "Content-Type": (result.metadata?.contentType as string) || "image/jpeg",
      "Cache-Control": "public, max-age=31536000, immutable",
    },
  });
};

export const config: Config = {
  path: "/api/photo/:id",
};
